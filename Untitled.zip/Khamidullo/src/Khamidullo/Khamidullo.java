package Khamidullo;

import java.awt.Color;
import java.awt.event.*;  
import javax.swing.*;  
@SuppressWarnings("serial")
public class Khamidullo extends JFrame implements ActionListener{  
JTextArea t;  
JButton b1,b2;  Khamidullo(){  
    super("Word Character Counter - JavaTpoint");  
    t=new JTextArea();  
    t.setBounds(30,60,300,200);  
    JLabel lb1;
    lb1=new JLabel("Word Counter"); 
    
    b1=new JButton("Word");  
    b1.setBounds(30,280,100,30);  
      
    b2=new JButton("Character");  
    b2.setBounds(180,280,100,30);  
      
    b1.addActionListener(this);  
    b2.addActionListener(this);  
    lb1.setBounds(30,30,150,20);
    add(b1);add(b2);add(t);  add(lb1);
    setSize(360,360);  
    setLayout(null);  
    setVisible(true);  
    t.setBackground(Color.LIGHT_GRAY); 
    
}  
public void actionPerformed(ActionEvent e){  
    String text=t.getText();  
    if(e.getSource()==b1){  
        String words[]=text.split("\\s");  
        JOptionPane.showMessageDialog(this,"Total words: "+words.length);  
    }  
    if(e.getSource()==b2){  
        JOptionPane.showMessageDialog(this,"Total Characters with space: "+text.length());  
    }  
}  
public static void main(String[] args) {  
    new Khamidullo();  
}  
}  