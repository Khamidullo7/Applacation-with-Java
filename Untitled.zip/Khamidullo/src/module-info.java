module Khamidullo {
	requires java.desktop;
}